// object.cpp
// Object description.
// Vladimir Rutsky, 4057/2
// 10.02.2010

#include "precompiled.h"

#include "object.h"
