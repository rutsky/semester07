// common_controls.h
// Common controls.
// Vladimir Rutsky, 4057/2
// 12.02.2010

#include "precompiled.h"

#include "common_controls.h"
