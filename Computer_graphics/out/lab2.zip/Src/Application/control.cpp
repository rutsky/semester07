// control.cpp
// User control.
// Vladimir Rutsky, 4057/2
// 10.02.2010

#include "precompiled.h"

#include "control.h"
