// constants.cpp
// Useful constants.
// Vladimir Rutsky, 4057/2
// 18.02.2010

#include "precompiled.h"

#include "constants.h"