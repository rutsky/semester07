// hierarchy.cpp
// Objects hierarchy classes declaration.
// Vladimir Rutsky, 4057/2
// 09.02.2010

#include "precompiled.h"

#include "hierarchy.h"
