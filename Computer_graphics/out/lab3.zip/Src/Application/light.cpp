// light.cpp
// Lights.
// Vladimir Rutsky, 4057/2
// 18.02.2010

#include "precompiled.h"

#include "light.h"
