tiger.x
tiger.bmp
  - from DirectX example

car00.x
ground_paletted.x 
ground00.bmp 
airplane00.x 
  - from http://sites.google.com/site/primatcg/fajly-i-ssylki
